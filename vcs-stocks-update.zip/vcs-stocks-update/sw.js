'use strict';
/* Service worker: (1) shows push notifications even when the app is closed, (2) lets the app open with no network. */
const CACHE = 'ks-shell-v109';
const SHELL = ['./', 'index.html', 'style.css', 'app.js', 'ui-plus.js', 'ks-extras.js', 'ks-extras.css', 'bottom-bar.css', 'bottom-bar.js', 'groups.css', 'groups.js', 'search.js', 'ks-cache.js', 'login-custom.js', 'native-push.js', 'tg-view.js', 'wa-view.js', 'websites-view.js', 'stock-view.js', 'pic2pdf-view.js', 'pdf2pics-view.js', 'attendance-reminder.js', 'ftp-view.js', 'status-view.js', 'theme-tab.js', 'ai-view.js', 'manifest.json', 'icon-192.png', 'logo.png', 'logo-sm.png', 'lic-icon.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(u => c.add(u).catch(() => {})))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE && k !== 'ks-prefs').map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

/* app files: network first (so a new deploy shows up at once), saved copy when there is no network */
self.addEventListener('fetch', e => {
  const r = e.request;
  if (r.method !== 'GET' || r.headers.has('range')) return;   // audio / video (ringtone loop) needs real range replies
  const u = new URL(r.url);
  if (u.origin !== self.location.origin) return;           // the API on Render is never touched here
  if (u.searchParams.has('_ksv')) return;                  // ks-cache.js build probe: always straight from the network
  if (r.mode === 'navigate' || /\/(index\.html)?$/.test(u.pathname)) { e.respondWith(pageFirst(r, u)); return; }   // the page itself: newest first
  // FAST: the saved copy opens instantly and is refreshed quietly in the background (stale-while-revalidate).
  // A new deploy still shows up: ks-cache.js clears the saved copy once when the deploy stamp changes, and a new ?v= is a new file.
  e.respondWith(swr(e, r, u));
});
async function swr(e, req, u) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req) || (req.mode === 'navigate' ? await cache.match('index.html', { ignoreSearch: true }) || await cache.match('./') : null);
  const refresh = fetch(req, { cache: 'no-cache' }).then(res => {
    if (res && res.ok && res.type === 'basic') {
      const copy = res.clone();
      cache.keys().then(async ks => {
        await Promise.all(ks.filter(k => new URL(k.url).pathname === u.pathname && k.url !== req.url).map(k => cache.delete(k)));
        await cache.put(req, copy);
      }).catch(() => {});
    }
    return res;
  });
  if (hit) { e.waitUntil(refresh.catch(() => {})); return hit; }
  return netFirst(req, u);                                  // first visit / not saved yet: normal network load
}
async function pageFirst(req, u) {                         // network first (2.5 s), saved copy when slow / offline
  const cache = await caches.open(CACHE);
  try {
    const res = await Promise.race([fetch(req, { cache: 'no-cache' }), new Promise((_, no) => setTimeout(() => no(new Error('slow')), 2500))]);
    if (res && res.ok && res.type === 'basic') { const copy = res.clone(); cache.put(req, copy).catch(() => {}); }
    return res;
  } catch (err) {
    const hit = await cache.match(req) || await cache.match('index.html', { ignoreSearch: true }) || await cache.match('./');
    if (hit) return hit;
    throw err;
  }
}
async function cacheFirst(req, u) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(req);
  if (hit) return hit;
  return netFirst(req, u);
}
async function netFirst(req, u) {
  const cache = await caches.open(CACHE);
  try {
    const res = await Promise.race([req.mode === 'navigate' ? fetch(req) : fetch(req, { cache: 'no-cache' }), new Promise((_, no) => setTimeout(() => no(new Error('slow')), 6000))]);
    if (res && res.ok && res.type === 'basic') {
      const copy = res.clone();
      cache.keys().then(async ks => {                       // keep one copy per file (drop older ?v= versions)
        await Promise.all(ks.filter(k => new URL(k.url).pathname === u.pathname && k.url !== req.url).map(k => cache.delete(k)));
        await cache.put(req, copy);
      }).catch(() => {});
    }
    return res;
  } catch (err) {
    const hit = await cache.match(req, { ignoreSearch: true })
      || (req.mode === 'navigate' ? (await cache.match('index.html', { ignoreSearch: true })) || (await cache.match('./')) : null);
    if (hit) return hit;
    throw err;
  }
}

/* push: the server sends { title, body, tag, url, kind, ts } */
self.addEventListener('push', e => {
  let d = {};
  try { d = e.data ? e.data.json() : {}; } catch (x) { d = { title: 'KS', body: e.data ? e.data.text() : '' }; }
  const call = d.kind === 'call', msg = d.kind === 'msg';
  // call: long buzz-pause pattern (~30 s, like a ringing phone). message: two short buzzes.
  const ring = []; for (let i = 0; i < 20; i++) ring.push(900, 600);
  e.waitUntil((async () => {
    let pf = {}; try { const r = await (await caches.open('ks-prefs')).match('prefs'); if (r) pf = await r.json(); } catch (x) {}   // Settings > Smart options (saved by the app)
    const snd = call ? pf.csnd !== 0 : msg ? pf.msnd !== 0 : true, vib = call ? pf.cvib !== 0 : msg ? pf.mvib !== 0 : true;
    const cl0 = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    const visible = cl0.some(c => c.visibilityState === 'visible');
    if (visible && (call || msg)) {
      // the app is open on screen: it rings / plays your own tone itself, so no system notification (its default sound played together with your tone)
      cl0.forEach(c => c.postMessage({ type: 'push', kind: d.kind || '', callId: d.callId || '' }));
      return;
    }
    await self.registration.showNotification(d.title || 'KS', {
      body: d.body || '',
      tag: d.tag || 'ks',
      renotify: true,
      silent: !snd && !vib,                                  // use the phone's notification sound (silent only when sound AND vibration are both off)
      icon: 'icon-192.png',
      badge: 'badge-72.png',
      timestamp: d.ts || Date.now(),
      requireInteraction: call,                              // an incoming call stays on screen until you tap it
      vibrate: !vib ? [] : call ? (Array.isArray(pf.cva) && pf.cva.length ? pf.cva : ring) : msg ? (Array.isArray(pf.mva) && pf.mva.length ? pf.mva : [250, 120, 250]) : [200, 100, 200],
      data: { url: d.url || './', kind: d.kind || '', callId: d.callId || '', view: d.view || '', with: d.with || '' }
    });
    const cl = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    cl.forEach(c => c.postMessage({ type: 'push', kind: d.kind || '', callId: d.callId || '' }));   // an open app reacts at once
  })());
});

self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = new URL((e.notification.data && e.notification.data.url) || './', self.registration.scope).href;
  e.waitUntil((async () => {
    const cl = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of cl) {
      if (c.url.startsWith(self.registration.scope)) {
        try { await c.focus(); } catch (x) {}
        c.postMessage({ type: 'nav', url, kind: (e.notification.data || {}).kind || '', view: (e.notification.data || {}).view || '', with: (e.notification.data || {}).with || '' });
        return;
      }
    }
    await self.clients.openWindow(url);
  })());
});
